#include <iostream>
using namespace std;


int calculateDiscount(int total) {
    if (total >= 5000) {
        return total - (total * 0.20);
    } else if (total >= 3000) {
        return total - (total * 0.15);
    } else if (total >= 1000) {
        return total - (total * 0.10);
    } else {
        return total;
    }
}


void testDiscounts() {
    int test1 = 6000;
    int test2 = 3000;
    int test3 = 500;

    cout << "Test Case 1 - Total: 6000  Final: " << calculateDiscount(test1) << endl;
    cout << "Test Case 2 - Total: 3000  Final: " << calculateDiscount(test2) << endl;
    cout << "Test Case 3 - Total: 500   Final: " << calculateDiscount(test3) << endl;
}

int main() {
    testDiscounts();
    return 0;
}
