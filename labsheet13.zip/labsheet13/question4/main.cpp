#include <iostream>
using namespace std;

const int DAYS = 3;
const int HOURS = 4;


void findMaxTemp(int temps[DAYS][HOURS]) {
    int maxTemp = temps[0][0];

    for (int i = 0; i < DAYS; i++) {
        for (int j = 0; j < HOURS; j++) {
            if (temps[i][j] > maxTemp) {
                maxTemp = temps[i][j];
            }
        }
    }

    cout << "\nThe highest temperature recorded is: " << maxTemp << "C" << endl;
}

int main() {
    int temps[DAYS][HOURS];

    cout << "Enter temperature readings for 3 days (4 readings each):\n";
    for (int i = 0; i < DAYS; i++) {
        cout << "Day " << i + 1 << ":\n";
        for (int j = 0; j < HOURS; j++) {
            cout << "  Hour " << j + 1 << ": ";
            cin >> temps[i][j];
        }
    }


    findMaxTemp(temps);

    return 0;
}


