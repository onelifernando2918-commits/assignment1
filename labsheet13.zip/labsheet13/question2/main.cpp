#include <iostream>
using namespace std;

const int STUDENTS = 4;
const int SUBJECTS = 3;


void computeGrades(int marks[STUDENTS][SUBJECTS]) {
    for (int i = 0; i < STUDENTS; i++) {
        int total = 0;
        for (int j = 0; j < SUBJECTS; j++) {
            total += marks[i][j];
        }

        float average = total / (float)SUBJECTS;
        char grade;


        if (average >= 75) {
            grade = 'A';
        } else {
            if (average >= 60) {
                grade = 'B';
            } else {
                if (average >= 50) {
                    grade = 'C';
                } else {
                    grade = 'F';
                }
            }
        }

        cout << "Student " << i + 1 << " - Average: " << average << ", Grade: " << grade << endl;
    }
}

int main() {
    int marks[STUDENTS][SUBJECTS];


    cout << "Enter marks for 4 students (3 subjects each):\n";
    for (int i = 0; i < STUDENTS; i++) {
        cout << "Student " << i + 1 << ":\n";
        for (int j = 0; j < SUBJECTS; j++) {
            cout << "  Subject " << j + 1 << ": ";
            cin >> marks[i][j];
        }
    }


    computeGrades(marks);

    return 0;
}

