#include <iostream>
using namespace std;


const int ROWS = 5;
const int SEATS_PER_ROW = 6;


int cinema[ROWS][SEATS_PER_ROW] = {0};


void bookSeat(int row, int seat) {

    if (row < 1 || row > ROWS || seat < 1 || seat > SEATS_PER_ROW) {
        cout << "Invalid seat selection. Please try again." << endl;
        return;
    }


    row--;
    seat--;


    if (cinema[row][seat] == 0) {
        cinema[row][seat] = 1;
        cout << "Seat successfully booked at Row " << row + 1 << ", Seat " << seat + 1 << "." << endl;
    } else {
        cout << "Seat already booked. Please choose a different seat." << endl;
    }
}


void displaySeating() {
    cout << "\nCurrent Seating (0 = Available, 1 = Booked):\n";
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < SEATS_PER_ROW; j++) {
            cout << cinema[i][j] << " ";
        }
        cout << endl;
    }
}

int main() {
    int row, seat;

    displaySeating();


    cout << "Enter row (1-5) and seat (1-6) to book: "<<endl;;
    cin >> row >> seat;
    bookSeat(row, seat);

    displaySeating();

    return 0;
}




