#include <iostream>
using namespace std;

const int FLOORS = 4;
const int ROOMS = 3;


void displayStatus(int hotel[FLOORS][ROOMS]) {
    cout << "\nHotel Room Status:\n";
    for (int i = 0; i < FLOORS; i++) {
        for (int j = 0; j < ROOMS; j++) {
            cout << "Floor " << i + 1 << ", Room " << j + 1 << ": ";
            if (hotel[i][j] == 1)
                cout << "Occupied";
            else
                cout << "Vacant";
            cout << endl;
        }
    }
}

int main() {

    int hotel[FLOORS][ROOMS] = {
        {1, 0, 1},
        {0, 0, 1},
        {1, 1, 0},
        {0, 1, 0}
    };


    displayStatus(hotel);

    return 0;
}

